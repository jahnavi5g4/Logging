package com.epam.clean_code;

public class CostConstruction {

	public int cost(int area,int cost) {
		return area*cost;
	}

}
